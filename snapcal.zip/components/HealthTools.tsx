import React, { useState, useRef } from 'react';
import { UserProfile, Gender } from '../types';
import { analyzeIngredientLabel, IngredientAnalysis } from '../services/geminiService';
import { 
  Swords, 
  Trophy, 
  ScanBarcode, 
  ShieldCheck, 
  BarChartBig, 
  Flame, 
  Percent, 
  Activity, 
  ArrowDownUp, 
  HeartPulse, 
  ChevronLeft, 
  Minus, 
  Plus, 
  X, 
  Camera, 
  Loader2, 
  CheckCircle 
} from 'lucide-react';

interface HealthToolsProps {
  user: UserProfile;
}

const ToolHeader: React.FC<{ title: string; onBack: () => void }> = ({ title, onBack }) => (
    <div className="relative flex items-center justify-center px-6 mb-6">
        <button onClick={onBack} className="absolute left-6 p-2 -ml-2 rounded-full hover:bg-white hover:shadow-sm text-gray-700 transition-all">
            <ChevronLeft className="w-6 h-6" />
        </button>
        <h1 className="text-xl font-extrabold text-gray-900">{title}</h1>
    </div>
);

const BMICalculator: React.FC<{ user: UserProfile, onBack: () => void }> = ({ user, onBack }) => {
    const heightM = user.height / 100;
    const bmi = user.weight / (heightM * heightM);
    
    let status = '正常';
    let color = 'text-green-500';
    if (bmi < 18.5) { status = '偏瘦'; color = 'text-blue-500'; }
    else if (bmi >= 24) { status = '超重'; color = 'text-orange-500'; }
    if (bmi >= 28) { status = '肥胖'; color = 'text-red-500'; }

    return (
        <div className="min-h-screen bg-gray-50 pt-6 animate-in slide-in-from-right">
            <ToolHeader title="BMI 计算器" onBack={onBack} />
            <div className="px-6 space-y-6">
                <div className="bg-white rounded-[2rem] p-8 text-center shadow-sm">
                    <div className="text-sm font-bold text-gray-400 mb-2">您的 BMI 指数</div>
                    <div className={`text-6xl font-extrabold ${color} mb-2`}>{bmi.toFixed(1)}</div>
                    <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold bg-gray-100 ${color}`}>{status}</div>
                </div>
                <div className="bg-white rounded-[2rem] p-6 shadow-sm space-y-4">
                    <h3 className="font-bold text-gray-900">BMI 标准参考</h3>
                    <div className="space-y-2 text-sm">
                        <div className="flex justify-between"><span className="text-gray-500">偏瘦</span><span className="font-bold">&lt; 18.5</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">正常</span><span className="font-bold">18.5 - 23.9</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">超重</span><span className="font-bold">24.0 - 27.9</span></div>
                        <div className="flex justify-between"><span className="text-gray-500">肥胖</span><span className="font-bold">≥ 28.0</span></div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const BMRCalculator: React.FC<{ user: UserProfile, onBack: () => void }> = ({ user, onBack }) => {
    // Mifflin-St Jeor
    let bmr = (10 * user.weight) + (6.25 * user.height) - (5 * user.age);
    bmr += user.gender === Gender.MALE ? 5 : -161;
    
    return (
        <div className="min-h-screen bg-gray-50 pt-6 animate-in slide-in-from-right">
            <ToolHeader title="基础代谢率 (BMR)" onBack={onBack} />
             <div className="px-6 space-y-6">
                <div className="bg-white rounded-[2rem] p-8 text-center shadow-sm border border-orange-50">
                    <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center text-orange-500 mx-auto mb-4"><Flame className="w-6 h-6"/></div>
                    <div className="text-sm font-bold text-gray-400 mb-2">每日静息消耗</div>
                    <div className="text-5xl font-extrabold text-gray-900 mb-2">{Math.round(bmr)}</div>
                    <div className="text-xs font-bold text-gray-400">kcal / 天</div>
                </div>
                <div className="bg-white rounded-[2rem] p-6 shadow-sm">
                     <p className="text-sm text-gray-500 leading-relaxed">
                        基础代谢率是指您在清醒且极端安静的状态下，不受肌肉活动、环境温度、食物及精神紧张等影响时的能量代谢率。
                     </p>
                </div>
            </div>
        </div>
    );
};

const BFRCalculator: React.FC<{ user: UserProfile, onBack: () => void }> = ({ user, onBack }) => {
    // Deurenberg formula
    const heightM = user.height / 100;
    const bmi = user.weight / (heightM * heightM);
    const sexValue = user.gender === Gender.MALE ? 1 : 0;
    const bfr = (1.20 * bmi) + (0.23 * user.age) - (10.8 * sexValue) - 5.4;

    return (
        <div className="min-h-screen bg-gray-50 pt-6 animate-in slide-in-from-right">
            <ToolHeader title="体脂率 (BFR)" onBack={onBack} />
             <div className="px-6 space-y-6">
                <div className="bg-white rounded-[2rem] p-8 text-center shadow-sm border border-purple-50">
                     <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center text-purple-500 mx-auto mb-4"><Percent className="w-6 h-6"/></div>
                    <div className="text-sm font-bold text-gray-400 mb-2">估算体脂率</div>
                    <div className="text-5xl font-extrabold text-gray-900 mb-2">{bfr.toFixed(1)}%</div>
                    <div className="text-xs font-bold text-gray-400">基于 BMI 公式估算</div>
                </div>
                <div className="bg-blue-50 p-4 rounded-xl text-xs text-blue-700 leading-relaxed">
                    注：此结果仅基于公式估算，可能与实际体脂率存在偏差。建议结合专业设备测量。
                </div>
            </div>
        </div>
    );
};

const RFMCalculator: React.FC<{ user: UserProfile, onBack: () => void }> = ({ user, onBack }) => {
    const [waist, setWaist] = useState<number>(80);
    // RFM Formula: 64 - (20 * height / waist) + 12 * sex (sex: men=0, women=1)
    const sexCoeff = user.gender === Gender.MALE ? 0 : 1; 
    const rfm = 64 - (20 * (user.height / waist)) + (12 * sexCoeff);

    return (
        <div className="min-h-screen bg-gray-50 pt-6 animate-in slide-in-from-right">
            <ToolHeader title="相对脂肪量 (RFM)" onBack={onBack} />
             <div className="px-6 space-y-6">
                <div className="bg-white rounded-[2rem] p-6 shadow-sm">
                    <label className="text-sm font-bold text-gray-700 block mb-4">请输入腰围 (cm)</label>
                    <div className="flex items-center justify-between bg-gray-50 rounded-xl p-2 mb-6">
                        <button onClick={() => setWaist(w => w - 1)} className="p-3 bg-white shadow-sm rounded-lg"><Minus className="w-4 h-4"/></button>
                        <span className="text-2xl font-extrabold text-gray-900">{waist}</span>
                        <button onClick={() => setWaist(w => w + 1)} className="p-3 bg-white shadow-sm rounded-lg"><Plus className="w-4 h-4"/></button>
                    </div>
                    
                    <div className="text-center pt-4 border-t border-gray-100">
                        <div className="text-sm font-bold text-gray-400 mb-1">RFM 指数</div>
                        <div className="text-4xl font-extrabold text-cyan-600">{rfm.toFixed(1)}%</div>
                    </div>
                </div>
                <p className="text-xs text-gray-400 px-2">RFM (Relative Fat Mass) 是一种被认为比 BMI 更准确的体脂评估方式，仅需身高和腰围数据。</p>
            </div>
        </div>
    );
};

const WHRCalculator: React.FC<{ user: UserProfile, onBack: () => void }> = ({ user, onBack }) => {
    const [waist, setWaist] = useState<number>(80);
    const [hip, setHip] = useState<number>(95);
    
    const whr = waist / hip;
    const isHealthy = user.gender === Gender.MALE ? whr < 0.9 : whr < 0.85;

    return (
        <div className="min-h-screen bg-gray-50 pt-6 animate-in slide-in-from-right">
            <ToolHeader title="腰臀比 (WHR)" onBack={onBack} />
             <div className="px-6 space-y-6">
                <div className="bg-white rounded-[2rem] p-6 shadow-sm space-y-6">
                     <div>
                        <label className="text-xs font-bold text-gray-400 block mb-2 uppercase">腰围 (cm)</label>
                        <input type="range" min="50" max="150" value={waist} onChange={e => setWaist(Number(e.target.value))} className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-indigo-500 mb-2"/>
                        <div className="text-center font-bold text-xl">{waist}</div>
                    </div>
                    <div>
                        <label className="text-xs font-bold text-gray-400 block mb-2 uppercase">臀围 (cm)</label>
                        <input type="range" min="50" max="150" value={hip} onChange={e => setHip(Number(e.target.value))} className="w-full h-2 bg-gray-100 rounded-lg appearance-none cursor-pointer accent-indigo-500 mb-2"/>
                        <div className="text-center font-bold text-xl">{hip}</div>
                    </div>

                    <div className="text-center pt-4 border-t border-gray-100">
                        <div className="text-sm font-bold text-gray-400 mb-1">腰臀比</div>
                        <div className="text-4xl font-extrabold text-indigo-600 mb-2">{whr.toFixed(2)}</div>
                         <div className={`inline-block px-3 py-1 rounded-full text-xs font-bold ${isHealthy ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                             {isHealthy ? '健康范围' : '中心性肥胖风险'}
                         </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const HeartRateCalculator: React.FC<{ user: UserProfile, onBack: () => void }> = ({ user, onBack }) => {
    const maxHr = 220 - user.age;
    const burnMin = Math.round(maxHr * 0.6);
    const burnMax = Math.round(maxHr * 0.8);

    return (
        <div className="min-h-screen bg-gray-50 pt-6 animate-in slide-in-from-right">
            <ToolHeader title="燃脂心率" onBack={onBack} />
             <div className="px-6 space-y-6">
                <div className="bg-white rounded-[2rem] p-8 text-center shadow-sm border border-red-50">
                    <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center text-red-500 mx-auto mb-4 animate-pulse"><HeartPulse className="w-6 h-6"/></div>
                    <div className="text-sm font-bold text-gray-400 mb-2">最佳燃脂区间</div>
                    <div className="text-4xl font-extrabold text-gray-900 mb-2">{burnMin} - {burnMax} <span className="text-sm font-medium text-gray-400">bpm</span></div>
                    <div className="text-xs font-bold text-gray-400">最大心率: {maxHr} bpm</div>
                </div>
                <div className="space-y-3">
                    <h3 className="font-bold text-gray-900 px-2">心率区间说明</h3>
                    <div className="bg-white p-4 rounded-2xl flex items-center gap-4">
                        <div className="w-2 h-10 bg-gray-200 rounded-full"></div>
                        <div>
                            <div className="font-bold text-gray-900">热身/恢复 (50-60%)</div>
                            <div className="text-xs text-gray-400">{Math.round(maxHr * 0.5)} - {Math.round(maxHr * 0.6)} bpm</div>
                        </div>
                    </div>
                     <div className="bg-white p-4 rounded-2xl flex items-center gap-4 border-l-4 border-red-500 shadow-sm">
                        <div className="w-2 h-10 bg-red-500 rounded-full"></div>
                        <div>
                            <div className="font-bold text-red-600">燃脂区间 (60-80%)</div>
                            <div className="text-xs text-gray-400">{burnMin} - {burnMax} bpm</div>
                        </div>
                    </div>
                     <div className="bg-white p-4 rounded-2xl flex items-center gap-4">
                        <div className="w-2 h-10 bg-orange-400 rounded-full"></div>
                        <div>
                            <div className="font-bold text-gray-900">心肺强化 (80-90%)</div>
                            <div className="text-xs text-gray-400">{Math.round(maxHr * 0.8)} - {Math.round(maxHr * 0.9)} bpm</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

const IngredientScanner: React.FC<{ onBack: () => void }> = ({ onBack }) => {
    const [image, setImage] = useState<string | null>(null);
    const [analysis, setAnalysis] = useState<IngredientAnalysis | null>(null);
    const [loading, setLoading] = useState(false);
    const fileInputRef = useRef<HTMLInputElement>(null);

    const handleFile = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;

        const reader = new FileReader();
        reader.onloadend = async () => {
            const base64 = reader.result as string;
            setImage(base64);
            setLoading(true);
            try {
                const result = await analyzeIngredientLabel(base64);
                setAnalysis(result);
            } catch (err) {
                alert("识别失败，请重试");
            } finally {
                setLoading(false);
            }
        };
        reader.readAsDataURL(file);
    };

    return (
        <div className="min-h-screen bg-gray-900 text-white pt-6 animate-in slide-in-from-right">
            <div className="relative flex items-center justify-center px-6 mb-6">
                <button onClick={onBack} className="absolute left-6 p-2 -ml-2 rounded-full hover:bg-gray-800 text-gray-300 transition-all">
                    <X className="w-6 h-6" />
                </button>
                <h1 className="text-xl font-extrabold">配料表分析</h1>
            </div>

            <div className="px-5">
                {!image ? (
                     <div 
                        onClick={() => fileInputRef.current?.click()}
                        className="aspect-[3/4] rounded-[2rem] border-2 border-dashed border-gray-700 flex flex-col items-center justify-center bg-gray-800/50 hover:bg-gray-800 transition-colors cursor-pointer"
                     >
                         <Camera className="w-12 h-12 text-gray-500 mb-4" />
                         <span className="font-bold text-gray-400">点击拍摄配料表</span>
                         <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
                     </div>
                ) : (
                    <div className="space-y-6">
                         <div className="relative h-48 rounded-[2rem] overflow-hidden">
                             <img src={image} className="w-full h-full object-cover opacity-60" alt="Ingredients" />
                             {loading && (
                                 <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-sm">
                                     <Loader2 className="w-8 h-8 text-green-500 animate-spin mb-2" />
                                     <span className="font-bold text-sm">AI 分析中...</span>
                                 </div>
                             )}
                         </div>

                         {analysis && (
                             <div className="animate-in slide-in-from-bottom duration-500">
                                 <div className="flex items-center justify-between mb-6">
                                     <div>
                                         <div className="text-sm font-bold text-gray-400">健康评分</div>
                                         <div className={`text-4xl font-extrabold ${analysis.score > 80 ? 'text-green-500' : analysis.score > 60 ? 'text-yellow-500' : 'text-red-500'}`}>
                                             {analysis.score}
                                         </div>
                                     </div>
                                     <div className="text-right max-w-[60%]">
                                         <div className="text-xs text-gray-300 leading-relaxed">{analysis.summary}</div>
                                     </div>
                                 </div>

                                 <div className="space-y-3">
                                     <h3 className="font-bold text-gray-300 mb-2">成分风险提示</h3>
                                     {analysis.concerns.length === 0 ? (
                                         <div className="bg-green-500/10 border border-green-500/20 p-4 rounded-xl flex items-center gap-3">
                                             <CheckCircle className="w-5 h-5 text-green-500" />
                                             <span className="text-sm font-bold text-green-500">未发现明显风险成分</span>
                                         </div>
                                     ) : (
                                         analysis.concerns.map((concern, idx) => (
                                             <div key={idx} className="bg-gray-800 p-4 rounded-xl border border-gray-700">
                                                 <div className="flex justify-between items-start mb-1">
                                                     <span className="font-bold text-gray-200">{concern.name}</span>
                                                     <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                                         concern.risk === 'High' ? 'bg-red-500/20 text-red-400' : 
                                                         concern.risk === 'Medium' ? 'bg-yellow-500/20 text-yellow-400' : 'bg-blue-500/20 text-blue-400'
                                                     }`}>{concern.risk} 风险</span>
                                                 </div>
                                                 <p className="text-xs text-gray-500">{concern.description}</p>
                                             </div>
                                         ))
                                     )}
                                 </div>
                                 
                                 <button onClick={() => { setImage(null); setAnalysis(null); }} className="w-full py-4 bg-gray-800 rounded-xl font-bold text-gray-300 mt-6 hover:bg-gray-700 transition-colors">
                                     重新扫描
                                 </button>
                             </div>
                         )}
                    </div>
                )}
            </div>
        </div>
    );
};

export const HealthTools: React.FC<HealthToolsProps> = ({ user }) => {
  const [activeTool, setActiveTool] = useState<string | null>(null);

  if (activeTool === 'BMI') {
      return <BMICalculator user={user} onBack={() => setActiveTool(null)} />;
  }
  
  if (activeTool === 'RFM') {
      return <RFMCalculator user={user} onBack={() => setActiveTool(null)} />;
  }

  if (activeTool === 'BMR') {
      return <BMRCalculator user={user} onBack={() => setActiveTool(null)} />;
  }

  if (activeTool === 'INGREDIENT') {
      return <IngredientScanner onBack={() => setActiveTool(null)} />;
  }

  if (activeTool === 'BFR') {
      return <BFRCalculator user={user} onBack={() => setActiveTool(null)} />;
  }

  if (activeTool === 'WHR') {
      return <WHRCalculator user={user} onBack={() => setActiveTool(null)} />;
  }

  if (activeTool === 'HR') {
      return <HeartRateCalculator user={user} onBack={() => setActiveTool(null)} />;
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-32 pt-6 font-sans">
      {/* Header */}
      <div className="relative flex items-center justify-center px-6 mb-6">
        <h1 className="text-xl font-extrabold text-gray-900">健康驿站</h1>
      </div>

      <div className="px-5 space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
        
        {/* Card 1: Slimming Battle */}
        <div className="relative bg-gradient-to-br from-blue-50 to-blue-100 rounded-[2rem] p-6 overflow-hidden shadow-sm border border-blue-50 h-48 flex flex-col justify-center">
            {/* Visuals - Right Side */}
            <div className="absolute right-0 top-1/2 -translate-y-1/2 w-36 h-36 flex items-center justify-center opacity-90">
                <div className="relative">
                   <div className="absolute inset-0 bg-white/40 blur-3xl rounded-full scale-150"></div>
                   <div className="relative flex items-center justify-center">
                        <Swords className="w-24 h-24 text-blue-200/80 absolute rotate-12 drop-shadow-sm" strokeWidth={2} />
                        <Trophy className="w-20 h-20 text-yellow-500 fill-yellow-200 relative z-10 drop-shadow-lg -rotate-6" strokeWidth={1.5} />
                   </div>
                </div>
            </div>
            
            <div className="relative z-10 w-2/3">
                <div className="inline-block px-2.5 py-1 bg-yellow-400 text-yellow-900 text-[10px] font-bold rounded-lg mb-3 shadow-sm">
                    热门活动
                </div>
                <h2 className="text-xl font-extrabold text-gray-900 mb-2 leading-tight">瘦身大作战</h2>
                <p className="text-xs text-gray-500 font-bold leading-relaxed mb-4">
                    与好友一起减脂，共同坚持更有动力!
                </p>
                <button className="bg-white text-gray-900 px-5 py-2 rounded-full text-xs font-bold shadow-sm hover:bg-gray-50 transition-colors">
                    立即参与
                </button>
            </div>
        </div>

        {/* Card 2: Ingredient Check */}
        <div className="relative bg-gradient-to-br from-green-50 to-emerald-100 rounded-[2rem] p-6 overflow-hidden shadow-sm border border-green-50 h-48 flex flex-col justify-center">
            {/* Visuals - Right Side */}
             <div className="absolute right-4 top-1/2 -translate-y-1/2 w-32 h-32 flex items-center justify-center opacity-90">
                 <div className="relative">
                   <div className="absolute inset-0 bg-white/40 blur-2xl rounded-full scale-150"></div>
                   <div className="flex items-center justify-center">
                        <ScanBarcode className="w-24 h-24 text-emerald-600/20 absolute scale-125 rotate-3" strokeWidth={1.5} />
                        <ShieldCheck className="w-16 h-16 text-emerald-500 fill-emerald-100 relative z-10 drop-shadow-md -rotate-6" strokeWidth={1.5} />
                   </div>
                </div>
            </div>
            
             <div className="relative z-10 w-2/3">
                <div className="inline-block px-2.5 py-1 bg-green-500 text-white text-[10px] font-bold rounded-lg mb-3 shadow-sm">
                    AI智能
                </div>
                <h2 className="text-xl font-extrabold text-gray-900 mb-2 leading-tight">配料表识别</h2>
                <p className="text-xs text-gray-500 font-bold leading-relaxed mb-4">
                    AI智能识别配料安全性，守护健康饮食
                </p>
                <button 
                    onClick={() => setActiveTool('INGREDIENT')}
                    className="bg-green-100/80 text-green-800 px-5 py-2 rounded-full text-xs font-bold shadow-sm hover:bg-green-200 transition-colors backdrop-blur-sm"
                >
                    立即识别
                </button>
            </div>
        </div>

        {/* Section: Health Tools */}
        <div className="pt-4">
            <h3 className="text-base font-extrabold text-gray-900 mb-4 px-1">健康工具</h3>
            <div className="grid grid-cols-2 gap-3">
                {/* BMI */}
                <div 
                    onClick={() => setActiveTool('BMI')}
                    className="bg-white p-4 rounded-2xl border border-gray-50 shadow-sm flex flex-col items-center text-center h-32 justify-center hover:shadow-md transition-shadow cursor-pointer hover:bg-blue-50/30"
                >
                    <div className="w-10 h-10 bg-blue-50 rounded-xl flex items-center justify-center text-blue-500 mb-3">
                        <BarChartBig className="w-5 h-5 fill-blue-200" />
                    </div>
                    <div className="font-extrabold text-sm text-gray-900 mb-1">BMI查询</div>
                    <div className="text-[10px] text-gray-400 font-bold leading-tight px-1">了解你的体质指数</div>
                </div>

                {/* BMR */}
                <div 
                    onClick={() => setActiveTool('BMR')}
                    className="bg-white p-4 rounded-2xl border border-gray-50 shadow-sm flex flex-col items-center text-center h-32 justify-center hover:shadow-md transition-shadow cursor-pointer hover:bg-orange-50/30"
                >
                    <div className="w-10 h-10 bg-orange-50 rounded-xl flex items-center justify-center text-orange-500 mb-3">
                        <Flame className="w-5 h-5 fill-orange-200" />
                    </div>
                    <div className="font-extrabold text-sm text-gray-900 mb-1">基础代谢率</div>
                    <div className="text-[10px] text-gray-400 font-bold leading-tight px-1">计算每日消耗热量</div>
                </div>

                {/* BFR */}
                <div 
                    onClick={() => setActiveTool('BFR')}
                    className="bg-white p-4 rounded-2xl border border-gray-50 shadow-sm flex flex-col items-center text-center h-32 justify-center hover:shadow-md transition-shadow cursor-pointer hover:bg-purple-50/30"
                >
                    <div className="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center text-purple-500 mb-3">
                        <Percent className="w-5 h-5" />
                    </div>
                    <div className="font-extrabold text-sm text-gray-900 mb-1">体脂率</div>
                    <div className="text-[10px] text-gray-400 font-bold leading-tight px-1">计算身体脂肪含量</div>
                </div>

                {/* RFM (Replaced Obesity Test) */}
                <div 
                    onClick={() => setActiveTool('RFM')}
                    className="bg-white p-4 rounded-2xl border border-gray-50 shadow-sm flex flex-col items-center text-center h-32 justify-center hover:shadow-md transition-shadow cursor-pointer hover:bg-cyan-50/30"
                >
                    <div className="w-10 h-10 bg-cyan-50 rounded-xl flex items-center justify-center text-cyan-500 mb-3">
                        <Activity className="w-5 h-5" />
                    </div>
                    <div className="font-extrabold text-sm text-gray-900 mb-1">相对脂肪量(RFM)</div>
                    <div className="text-[10px] text-gray-400 font-bold leading-tight px-1">更精准的体脂评估</div>
                </div>

                {/* WHR (New) */}
                <div 
                    onClick={() => setActiveTool('WHR')}
                    className="bg-white p-4 rounded-2xl border border-gray-50 shadow-sm flex flex-col items-center text-center h-32 justify-center hover:shadow-md transition-shadow cursor-pointer hover:bg-indigo-50/30"
                >
                    <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-500 mb-3">
                        <ArrowDownUp className="w-5 h-5" />
                    </div>
                    <div className="font-extrabold text-sm text-gray-900 mb-1">腰臀比(WHR)</div>
                    <div className="text-[10px] text-gray-400 font-bold leading-tight px-1">判定中心性肥胖</div>
                </div>

                {/* Heart Rate (New) */}
                <div 
                    onClick={() => setActiveTool('HR')}
                    className="bg-white p-4 rounded-2xl border border-gray-50 shadow-sm flex flex-col items-center text-center h-32 justify-center hover:shadow-md transition-shadow cursor-pointer hover:bg-red-50/30"
                >
                    <div className="w-10 h-10 bg-red-50 rounded-xl flex items-center justify-center text-red-500 mb-3">
                        <HeartPulse className="w-5 h-5" />
                    </div>
                    <div className="font-extrabold text-sm text-gray-900 mb-1">燃脂心率</div>
                    <div className="text-[10px] text-gray-400 font-bold leading-tight px-1">高效燃脂运动区间</div>
                </div>
            </div>
        </div>

      </div>
    </div>
  );
};